(window.webpackJsonp=window.webpackJsonp||[]).push([[3],{10:function(e,t,n){"use strict";n.d(t,"j",(function(){return i})),n.d(t,"m",(function(){return l})),n.d(t,"b",(function(){return o})),n.d(t,"a",(function(){return c})),n.d(t,"c",(function(){return s})),n.d(t,"h",(function(){return d})),n.d(t,"g",(function(){return m})),n.d(t,"f",(function(){return u})),n.d(t,"k",(function(){return p})),n.d(t,"e",(function(){return b})),n.d(t,"l",(function(){return g})),n.d(t,"d",(function(){return h})),n.d(t,"i",(function(){return f}));var a=n(0),r=n.n(a);const i=()=>r.a.createElement("svg",{version:"1.1",id:"Icons",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",viewBox:"0 0 32 32",xmlSpace:"preserve"},r.a.createElement("g",null,r.a.createElement("path",{d:"M26.8,25H5.2c-0.8,0-1.5-0.4-1.9-1.1c-0.4-0.7-0.3-1.5,0.1-2.2L4.5,20c1.8-2.7,2.7-5.8,2.7-9c0-3.7,2.4-7.1,5.9-8.3\nC13.7,1.6,14.8,1,16,1s2.3,0.6,2.9,1.7c3.5,1.2,5.9,4.6,5.9,8.3c0,3.2,0.9,6.3,2.7,9l1.1,1.7c0.4,0.7,0.5,1.5,0.1,2.2\nC28.4,24.6,27.6,25,26.8,25z"})),r.a.createElement("path",{d:"M11.1,27c0.5,2.3,2.5,4,4.9,4s4.4-1.7,4.9-4H11.1z"})),l=()=>r.a.createElement("svg",{version:"1.1",id:"Capa_1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",viewBox:"0 0 53 53",xmlSpace:"preserve"},r.a.createElement("path",{style:{fill:"#000000"},d:"M18.613,41.552l-7.907,4.313c-0.464,0.253-0.881,0.564-1.269,0.903C14.047,50.655,19.998,53,26.5,53\nc6.454,0,12.367-2.31,16.964-6.144c-0.424-0.358-0.884-0.68-1.394-0.934l-8.467-4.233c-1.094-0.547-1.785-1.665-1.785-2.888v-3.322\nc0.238-0.271,0.51-0.619,0.801-1.03c1.154-1.63,2.027-3.423,2.632-5.304c1.086-0.335,1.886-1.338,1.886-2.53v-3.546\nc0-0.78-0.347-1.477-0.886-1.965v-5.126c0,0,1.053-7.977-9.75-7.977s-9.75,7.977-9.75,7.977v5.126\nc-0.54,0.488-0.886,1.185-0.886,1.965v3.546c0,0.934,0.491,1.756,1.226,2.231c0.886,3.857,3.206,6.633,3.206,6.633v3.24\nC20.296,39.899,19.65,40.986,18.613,41.552z"}),r.a.createElement("g",null,r.a.createElement("path",{style:{fill:"#556080"},d:"M26.953,0.004C12.32-0.246,0.254,11.414,0.004,26.047C-0.138,34.344,3.56,41.801,9.448,46.76\nc0.385-0.336,0.798-0.644,1.257-0.894l7.907-4.313c1.037-0.566,1.683-1.653,1.683-2.835v-3.24c0,0-2.321-2.776-3.206-6.633\nc-0.734-0.475-1.226-1.296-1.226-2.231v-3.546c0-0.78,0.347-1.477,0.886-1.965v-5.126c0,0-1.053-7.977,9.75-7.977\ns9.75,7.977,9.75,7.977v5.126c0.54,0.488,0.886,1.185,0.886,1.965v3.546c0,1.192-0.8,2.195-1.886,2.53\nc-0.605,1.881-1.478,3.674-2.632,5.304c-0.291,0.411-0.563,0.759-0.801,1.03V38.8c0,1.223,0.691,2.342,1.785,2.888l8.467,4.233\nc0.508,0.254,0.967,0.575,1.39,0.932c5.71-4.762,9.399-11.882,9.536-19.9C53.246,12.32,41.587,0.254,26.953,0.004z"})),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null),r.a.createElement("g",null)),o=({onClick:e})=>r.a.createElement("svg",{onClick:e,xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-arrow-right"},r.a.createElement("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),r.a.createElement("polyline",{points:"12 5 19 12 12 19"})),c=({onClick:e})=>r.a.createElement("svg",{onClick:e,xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-arrow-left"},r.a.createElement("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),r.a.createElement("polyline",{points:"12 19 5 12 12 5"})),s=()=>r.a.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24"},r.a.createElement("path",{d:"M19,2H5A3,3,0,0,0,2,5V15a3,3,0,0,0,3,3H16.59l3.7,3.71A1,1,0,0,0,21,22a.84.84,0,0,0,.38-.08A1,1,0,0,0,22,21V5A3,3,0,0,0,19,2Zm1,16.59-2.29-2.3A1,1,0,0,0,17,16H5a1,1,0,0,1-1-1V5A1,1,0,0,1,5,4H19a1,1,0,0,1,1,1Z"})),d=()=>r.a.createElement("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r.a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.4568 4.04112C13.9465 3.89532 13.4071 4.14932 13.1944 4.63551L11.4182 8.6953C11.1189 9.37937 10.6332 10.0666 10.0591 10.6315C9.73613 10.9494 9.36405 11.2492 8.95658 11.4895C8.98513 11.6556 9 11.8262 9 12V18.7208C10.9662 19.2191 12.4652 19.4974 13.8747 19.5744C15.4555 19.6609 16.9683 19.4962 18.9391 19.0527C19.666 18.8891 20.238 18.2957 20.3907 17.5321L21.541 11.781C21.6647 11.1622 21.1914 10.5849 20.5604 10.5849H16.6805C15.4446 10.5849 14.5045 9.47514 14.7077 8.25607L15.2112 5.23469C15.2999 4.70287 14.9752 4.18923 14.4568 4.04112ZM8.50064 20.6575C10.5273 21.1716 12.1718 21.4844 13.7655 21.5715C15.5816 21.6707 17.2858 21.4748 19.3783 21.0039C20.9084 20.6595 22.0509 19.4293 22.3519 17.9244L23.5021 12.1732C23.8734 10.3168 22.4535 8.58487 20.5604 8.58487L16.6805 8.58487L17.184 5.56349C17.4399 4.02832 16.5027 2.54563 15.0062 2.11807C13.5333 1.69722 11.9761 2.4304 11.362 3.83387L9.58589 7.89366C9.39928 8.3202 9.0685 8.80035 8.65628 9.20602C8.43074 9.42798 8.20006 9.6089 7.97781 9.74442C7.45036 9.28166 6.75828 9 6 9H3C1.34315 9 0 10.3431 0 12V19C0 20.6569 1.34315 22 3 22H6C7.04478 22 7.96357 21.4664 8.50064 20.6575ZM3 11C2.44772 11 2 11.4477 2 12V19C2 19.5523 2.44772 20 3 20H6C6.46838 20 6.86381 19.677 6.97116 19.2404C6.98984 19.1644 7 19.0841 7 19V12C7 11.8064 6.946 11.6286 6.85273 11.4771C6.67511 11.1887 6.35916 11 6 11H3Z",fill:"#293644"})),m=()=>r.a.createElement("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"#F44336",xmlns:"http://www.w3.org/2000/svg"},r.a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.4568 4.04112C13.9465 3.89532 13.4071 4.14932 13.1944 4.63551L11.4182 8.6953C11.1189 9.37937 10.6332 10.0666 10.0591 10.6315C9.73613 10.9494 9.36405 11.2492 8.95658 11.4895C8.98513 11.6556 9 11.8262 9 12V18.7208C10.9662 19.2191 12.4652 19.4974 13.8747 19.5744C15.4555 19.6609 16.9683 19.4962 18.9391 19.0527C19.666 18.8891 20.238 18.2957 20.3907 17.5321L21.541 11.781C21.6647 11.1622 21.1914 10.5849 20.5604 10.5849H16.6805C15.4446 10.5849 14.5045 9.47514 14.7077 8.25607L15.2112 5.23469C15.2999 4.70287 14.9752 4.18923 14.4568 4.04112ZM8.50064 20.6575C10.5273 21.1716 12.1718 21.4844 13.7655 21.5715C15.5816 21.6707 17.2858 21.4748 19.3783 21.0039C20.9084 20.6595 22.0509 19.4293 22.3519 17.9244L23.5021 12.1732C23.8734 10.3168 22.4535 8.58487 20.5604 8.58487L16.6805 8.58487L17.184 5.56349C17.4399 4.02832 16.5027 2.54563 15.0062 2.11807C13.5333 1.69722 11.9761 2.4304 11.362 3.83387L9.58589 7.89366C9.39928 8.3202 9.0685 8.80035 8.65628 9.20602C8.43074 9.42798 8.20006 9.6089 7.97781 9.74442C7.45036 9.28166 6.75828 9 6 9H3C1.34315 9 0 10.3431 0 12V19C0 20.6569 1.34315 22 3 22H6C7.04478 22 7.96357 21.4664 8.50064 20.6575ZM3 11C2.44772 11 2 11.4477 2 12V19C2 19.5523 2.44772 20 3 20H6C6.46838 20 6.86381 19.677 6.97116 19.2404C6.98984 19.1644 7 19.0841 7 19V12C7 11.8064 6.946 11.6286 6.85273 11.4771C6.67511 11.1887 6.35916 11 6 11H3Z",fill:"#F44336"})),u=()=>r.a.createElement("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r.a.createElement("title",null,"info"),r.a.createElement("desc",null,"Created with Sketch."),r.a.createElement("g",{id:"Icons",stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd"},r.a.createElement("g",{id:"Outlined",transform:"translate(-442.000000, -288.000000)"},r.a.createElement("g",{id:"Action",transform:"translate(100.000000, 100.000000)"},r.a.createElement("g",{id:"Outlined-/-Action-/-info",transform:"translate(340.000000, 186.000000)"},r.a.createElement("g",null,r.a.createElement("polygon",{id:"Path",points:"0 0 24 0 24 24 0 24"}),r.a.createElement("path",{d:"M11,7 L13,7 L13,9 L11,9 L11,7 Z M11,11 L13,11 L13,17 L11,17 L11,11 Z M12,2 C6.48,2 2,6.48 2,12 C2,17.52 6.48,22 12,22 C17.52,22 22,17.52 22,12 C22,6.48 17.52,2 12,2 Z M12,20 C7.59,20 4,16.41 4,12 C4,7.59 7.59,4 12,4 C16.41,4 20,7.59 20,12 C20,16.41 16.41,20 12,20 Z",id:"🔹-Icon-Color",fill:"#1D1D1D"}))))))),p=()=>r.a.createElement("svg",{width:"11px",height:"14px",viewBox:"0 0 11 14",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},r.a.createElement("title",null,"play_arrow"),r.a.createElement("desc",null,"Created with Sketch."),r.a.createElement("g",{id:"Icons",stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd"},r.a.createElement("g",{id:"Rounded",transform:"translate(-753.000000, -955.000000)"},r.a.createElement("g",{id:"AV",transform:"translate(100.000000, 852.000000)"},r.a.createElement("g",{id:"-Round-/-AV-/-play_arrow",transform:"translate(646.000000, 98.000000)"},r.a.createElement("g",null,r.a.createElement("rect",{id:"Rectangle-Copy-50",x:"0",y:"0",width:"24",height:"24"}),r.a.createElement("path",{d:"M7,6.82 L7,17.18 C7,17.97 7.87,18.45 8.54,18.02 L16.68,12.84 C17.3,12.45 17.3,11.55 16.68,11.15 L8.54,5.98 C7.87,5.55 7,6.03 7,6.82 Z",id:"🔹Icon-Color",fill:"#1D1D1D"}))))))),b=()=>r.a.createElement("svg",{width:"24px",height:"24px",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-chevron-down"},r.a.createElement("polyline",{points:"6 9 12 15 18 9"})),g=()=>r.a.createElement("svg",{width:"24px",height:"24px",style:{transform:"rotate(180deg)"},xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-chevron-down"},r.a.createElement("polyline",{points:"6 9 12 15 18 9"})),h=()=>r.a.createElement("svg",{width:"24px",height:"24px",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-arrow-down-circle"},r.a.createElement("g",null,r.a.createElement("circle",{cx:"12",cy:"12",r:"10"}),r.a.createElement("polyline",{points:"8 12 12 16 16 12"}),r.a.createElement("line",{x1:"12",y1:"8",x2:"12",y2:"16"}))),f=()=>r.a.createElement("svg",{width:"24px",height:"24px",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-log-out"},r.a.createElement("path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"}),r.a.createElement("polyline",{points:"16 17 21 12 16 7"}),r.a.createElement("line",{x1:"21",y1:"12",x2:"9",y2:"12"}))},103:function(e,t,n){"use strict";n.d(t,"a",(function(){return r}));var a=n(1);const r=Object(a.b)("hr")` 
  width: 90%;
  margin: 2em 1.3em;
  background-color: rgb(48,48,50);
  height: .5px;
  border: none;
`},104:function(e,t,n){"use strict";var a=n(0),r=n.n(a),i=n(1);const l=Object(i.b)("div")` 
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  padding: .5em .5em;    
  background-color: white;
  /* height: 4vw;
  max-height: 4vw; */
  transition: filter 1s ease-in-out;

  div {
    height: 100%;
    flex-grow: 1;
    display: flex;
    align-items: center;
    margin-left: 1em;
    background-color: white;
  }

  time {
      position: absolute;
      top: 1em;
      right: 1em;
      color: gray;
      font-size: .5em;
    }
  h3 {

    padding: .1em;
    font-size: .9em;
    margin: 0;
    border-top-left-radius: .5em;
    border-top-right-radius: .5em;
    font-weight: bold;
    color: gray;

  }
`,o=Object(i.b)("img")` 
  flex-shrink: 0;
  width: 3vw;
  height: 3vw;      
  border-radius: 50%; 

  @media only screen and (max-width: 600px) {
     width: 6vw;
     height: 6vw;  
  }
`;t.a=({iconSrc:e,time:t,username:n})=>r.a.createElement(l,null,r.a.createElement(o,{src:e}),r.a.createElement("div",null,r.a.createElement("time",null,t),r.a.createElement("h3",null,`@${n} says...`)))},105:function(e,t,n){"use strict";var a=n(0),r=n.n(a),i=n(1);const l=Object(i.b)("a")`
  text-decoration: none;
`,o=Object(i.b)("div")` 
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: .5vw auto;
  width: 85%;
  box-shadow: 5px 5px 5px -3px #aaaaaa;
  border-radius: 1vw;
  border: 1px solid rgb(207, 217, 222);
  padding: 1em;
  :hover {
    opacity: .8;
  }
`,c=Object(i.b)("img")` 
  border-radius: 1vw;

`,s=Object(i.b)("span")` 
  color: gray;
  font-size: 1vw;
`,d=Object(i.b)("h3")`
 font-size: 1vw;
 margin: .6vw 0 .1vw 0;
 color: gray;
 font-weight: bold;
`,m=Object(i.b)("p")` 
  color: gray;
  font-size: .8vw;
  max-height: 35vh;
  overflow-y: scroll;
 
`;var u=n(103);t.a=({metaData:e})=>{var t;return r.a.createElement(r.a.Fragment,null,e.success?r.a.createElement(l,{href:e.ogUrl,target:"_blank"},r.a.createElement(o,null,r.a.createElement(d,null,e.ogTitle),r.a.createElement(s,null,e.ogUrl),r.a.createElement(c,{src:null===(t=e.ogImage)||void 0===t?void 0:t.url,alt:""}),r.a.createElement(u.a,null),r.a.createElement(m,null,e.ogDescription))):r.a.createElement("a",{rel:"noreferrer",href:e.requestUrl,target:"_blank"},e.requestUrl))}},11:function(e,t,n){"use strict";n.d(t,"d",(function(){return r})),n.d(t,"c",(function(){return i})),n.d(t,"a",(function(){return l}));var a=n(35);const r={type:a.c,payload:!0},i=e=>setTimeout(()=>e({type:a.c,payload:!1}),1e3),l=()=>({type:a.a});t.b={closeModal:l,openModal:(e,t)=>n=>{n({type:a.b,payload:{modalType:e,modalProps:t}})},showLoadingSpinner:()=>e=>{e({type:a.c,payload:!0})},hideLoadingSpinner:()=>e=>{e({type:a.c,payload:!1})}}},116:function(e,t,n){e.exports=n(146)},146:function(e,t,n){"use strict";n.r(t);var a=n(0),r=n.n(a),i=n(12),l=n.n(i),o=n(15),c=n(4),s=n(3),d=n(14),m=n(55),u=n(18);var p=(e={topicCategories:[]},t)=>{switch(t.type){case"GET_ALL_ENUMS":return{topicCategories:t.payload};default:return e}},b=n(6),g=n.n(b),h=n(7);var f={getAllEnums:()=>e=>g.a.get(h.a+"/enums").then(t=>e({type:"GET_ALL_ENUMS",payload:t.data}))},v=n(61),w=n(20),x=n(1);var E=x.a`
/*** The new CSS Reset - version 1.2.0 (last updated 23.7.2021) ***/

/* Remove all the styles of the "User-Agent-Stylesheet", except for the 'display' property */
/* *:where(:not(iframe, canvas, img, svg, video):not(svg *)) {
    all: unset;
    display: revert;
} */

/* Preferred box-sizing value */
*,
*::before,
*::after {
    box-sizing: border-box;
}

/*
    Remove list styles (bullets/numbers)
    in case you use it combine with normalize.css
*/
ol, ul {
    /* list-style: none; */
}

/* For images to not be able to exceed their container */
img {
    max-width: 100%;
}

/* removes spacing between cells in tables */
table {
    border-collapse: collapse;
}

/* revert the 'white-space' property for textarea elements on Safari */
textarea {
    white-space: revert;
}


  :root {
    --m-primary-color:  black;
    --m-primary-background-color:  #14213D;
    /* --m-primary-background-1-color: #37B381; */
    --m-primary-background-1-color: #87C232;

    --m-secondary-background-color: #83af9b;
    --m-primary-font-color: white;
    --m-primary-box-shadow: 5px 5px 10px #5a5a5a, -5px -5px 10px #ffffff; 
    --gutterSm: 0.4rem;
    --gutterMd: 0.8rem;
    --gutterLg: 1.6rem;
    --gutterXl: 2.4rem;
    --gutterXx: 7.2rem;
    --fontFamily: "Baloo 2", cursive;
    --fontSizeSm: 1.2rem;
    --fontSizeMd: 1.6rem;
    --fontSizeLg: 2.1rem;
    --fontSizeXl: 2.8rem;
    --fontSizeXx: 3.6rem;
    --lineHeightSm: 1.2;
    --lineHeightMd: 1.8;
    --transitionDuration: 300ms;
    --transitionTF: cubic-bezier(0.645, 0.045, 0.355, 1);

    /* color options 2  */

    /* --m-primary-background-2-color: #37B381; */
    --m-primary-background-2-color: #87C232;

    --m-secondary-background-2-color:  #242526;
    --m-menu-bg-color: #242526;
    /* floated labels */
    --inputPaddingV: var(--gutterSm);
    --inputPaddingH: var(--gutterLg);
    --inputFontSize: var(--fontSizeMd);
    --inputLineHeight: var(--lineHeightSm);
    --labelScaleFactor: 0.7;
    --labelDefaultPosY: 50%;
    --labelTransformedPosY: calc(
      (var(--labelDefaultPosY)) - 
      (var(--inputPaddingV) * var(--labelScaleFactor)) - 
      (var(--inputFontSize) * var(--inputLineHeight)) + .15em
    );
    --inputTransitionDuration: var(--transitionDuration);
    --inputTransitionTF: var(--transitionTF);

    --m-input-color: rgb(232,232,232);
    --m-danger-color: #E85D04;
    --m-trim-color:  #14213D;
    --m-danger-color-light: #E89660;

    /*      DROPDOWN       */
    --bg:  #242526;
    --bg-accent: #484a4f;
    --text-color: #dadce1;
    --nav-size: 7vh;
    --border: 1px solid #474a4d;
    --border-radius: 8px;
    --speed: .5s; 

  };

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  html {
    font-size: 10px;
    font-family: "Baloo 2", cursive;
    overflow-x: hidden;

  }
  .fade.modal.show {
    z-index: 999999;
  }


  .react-strap-modal {
    /* padding: 1em; */
    border: none;
    border-radius: 1em;
    width: 100%;
    background-color: white;
    z-index: 99999;

  }

  .modal-dialog {
    position: absolute;
    left: 50%;
    top: 50%;
    z-index: 99999;
    min-width: 55vw;
    min-height: 50vh;
    transform: translate(-50%, -50%) !important;
  }

  .modal-body {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  body {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100vw;
    padding: 0;
    margin: 0;
    font-family: var(--fontFamily);
    font-family: "Baloo 2", cursive;
    font-size: var(--fontSizeMd);
    line-height: var(--lineHeightMd);
  }

  .twitter-tweet {
    margin: 0 !important;
  }

   /* #twitter-widget-1::shadow div:last-child {
   display: none;
  } */

  ::-webkit-scrollbar {
    display: none;
  }

  /* .demo-wrapper, .demo-editor {
    display: flex;
    width: 100%;
    background-color: gray;
    height: 100%;
  } */

  /* .ap {
    background-image: url('/emoji-sprite.png') !important;
  } */

  .text-editor .ql-container {
    /* min-height: 10vw; */
    min-height: 7vh;
  }


/* 
  .menu-primary-enter {
    position: absolute;
    max-height: 0;
  }
  .menu-primary-enter-active {
    transform: translateX(0%);
    transition: all var(--speed) ease;
    max-height: 200px !important;
  }
  .menu-primary-exit {
    position: absolute;
  }
  .menu-primary-exit-active {
    transform: translateX(-110%);
    transition: all var(--speed) ease;
  } */


  .theme-tooltip {
    z-index: 999999999;
  }

  .popover {
    z-index: 999999999;
  }


  /* ******************************** CLERK RELATED STUFF ******************************** */
  .cl-component.cl-user-button {
    width: 4rem !important;
    height: 4rem !important;
    margin-right: 1rem;
  } 


  /*********************************  Toastify related stuff  ******************************** */

  .toasty {
    z-index: 99999999999;
  }

  /* ----------------------------------------------
 * Generated by Animista on 2021-12-4 17:46:39
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation slide-in-elliptic-top-fwd
 * ----------------------------------------
 */

.slide-in-elliptic-top-fwd {
-webkit-animation: slide-in-elliptic-top-fwd 1s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
animation: slide-in-elliptic-top-fwd 1s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
}

@-webkit-keyframes slide-in-elliptic-top-fwd {
  0% {
    -webkit-transform: translateY(-600px) rotateX(-30deg) scale(0);
            transform: translateY(-600px) rotateX(-30deg) scale(0);
    -webkit-transform-origin: 50% 100%;
            transform-origin: 50% 100%;
    opacity: 0;
  }
  100% {
    -webkit-transform: translateY(0) rotateX(0) scale(1);
            transform: translateY(0) rotateX(0) scale(1);
    -webkit-transform-origin: 50% 1400px;
            transform-origin: 50% 1400px;
    opacity: 1;
  }
}
@keyframes slide-in-elliptic-top-fwd {
  0% {
    -webkit-transform: translateY(-600px) rotateX(-30deg) scale(0);
            transform: translateY(-600px) rotateX(-30deg) scale(0);
    -webkit-transform-origin: 50% 100%;
            transform-origin: 50% 100%;
    opacity: 0;
  }
  100% {
    -webkit-transform: translateY(0) rotateX(0) scale(1);
            transform: translateY(0) rotateX(0) scale(1);
    -webkit-transform-origin: 50% 1400px;
            transform-origin: 50% 1400px;
    opacity: 1;
  }
}


/* ----------------------------------------------
 * Generated by Animista on 2021-12-4 17:50:9
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation slide-out-elliptic-bottom-bck
 * ----------------------------------------
 */

.slide-out-elliptic-bottom-bck {
-webkit-animation: slide-out-elliptic-bottom-bck 1s ease-in both;
animation: slide-out-elliptic-bottom-bck 1s ease-in both;
}
@-webkit-keyframes slide-out-elliptic-bottom-bck {
  0% {
    -webkit-transform: translateY(0) rotateX(0) scale(1);
            transform: translateY(0) rotateX(0) scale(1);
    -webkit-transform-origin: 50% -1400px;
            transform-origin: 50% -1400px;
    opacity: 1;
  }
  100% {
    -webkit-transform: translateY(600px) rotateX(30deg) scale(0);
            transform: translateY(600px) rotateX(30deg) scale(0);
    -webkit-transform-origin: 50% 100%;
            transform-origin: 50% 100%;
    opacity: 1;
  }
}
@keyframes slide-out-elliptic-bottom-bck {
  0% {
    -webkit-transform: translateY(0) rotateX(0) scale(1);
            transform: translateY(0) rotateX(0) scale(1);
    -webkit-transform-origin: 50% -1400px;
            transform-origin: 50% -1400px;
    opacity: 1;
  }
  100% {
    -webkit-transform: translateY(600px) rotateX(30deg) scale(0);
            transform: translateY(600px) rotateX(30deg) scale(0);
    -webkit-transform-origin: 50% 100%;
            transform-origin: 50% 100%;
    opacity: 1;
  }
}

/* ----------------------------------------------
 * Generated by Animista on 2021-12-4 18:7:41
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation text-pop-up-top
 * ----------------------------------------
 */

.text-pop-up-top {
-webkit-animation: tracking-in-expand 0.7s cubic-bezier(0.215, 0.610, 0.355, 1.000) both;
animation: tracking-in-expand 0.7s cubic-bezier(0.215, 0.610, 0.355, 1.000) both;
}
/* ----------------------------------------------
 * Generated by Animista on 2021-12-4 18:10:19
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation tracking-in-contract-bck
 * ----------------------------------------
 */
/* ----------------------------------------------
 * Generated by Animista on 2021-12-4 18:11:44
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation tracking-in-expand
 * ----------------------------------------
 */
@-webkit-keyframes tracking-in-expand {
  0% {
    letter-spacing: -0.5em;
    opacity: 0;
  }
  40% {
    opacity: 0.6;
  }
  100% {
    opacity: 1;
  }
}
@keyframes tracking-in-expand {
  0% {
    letter-spacing: -0.5em;
    opacity: 0;
  }
  40% {
    opacity: 0.6;
  }
  100% {
    opacity: 1;
  }
}


/* ----------------------------------------------
 * Generated by Animista on 2021-12-4 20:20:48
 * Licensed under FreeBSD License.
 * See http://animista.net/license for more info. 
 * w: http://animista.net, t: @cssanimista
 * ---------------------------------------------- */

/**
 * ----------------------------------------
 * animation text-focus-in
 * ----------------------------------------
 */
@-webkit-keyframes text-focus-in {
  0% {
    -webkit-filter: blur(12px);
            filter: blur(12px);
    opacity: 0;
  }
  100% {
    -webkit-filter: blur(0px);
            filter: blur(0px);
    opacity: 1;
  }
}
@keyframes text-focus-in {
  0% {
    -webkit-filter: blur(12px);
            filter: blur(12px);
    opacity: 0;
  }
  100% {
    -webkit-filter: blur(0px);
            filter: blur(0px);
    opacity: 1;
  }
}


.text-focus-in {
-webkit-animation: text-focus-in 1s cubic-bezier(0.550, 0.085, 0.680, 0.530) both;
animation: text-focus-in 1s cubic-bezier(0.550, 0.085, 0.680, 0.530) both;
}







`,y=n(11);const k=Object(x.b)("div")`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,O=(Object(x.b)("a")`
  display: flex;
  align-items: center;
  justify-content: center;
  transition: filter 300ms;

  :hover {
    filter: brightness(.9);
  }

`,()=>{const{state:e}=Object(c.f)();return r.a.createElement(k,null,r.a.createElement(u.b,{signUpUrl:"/signup",afterSignInUrl:null==e?void 0:e.redirectPath}))}),j=()=>r.a.createElement(k,null,r.a.createElement(u.c,{signInUrl:"/signin"}));const C=Object(x.b)("button")` 
  cursor: pointer;
  border: none;
  outline: none;
  font-weight: bold;
  /* font-size: 1.7em; */
  background: transparent;
   :hover {
    filter: drop-shadow(0 2px 4px black) brightness(.8);
  }
`;var S=({icon:e,children:t,onClick:n,disabled:i,rest:l})=>{const o=Object(a.useCallback)(e=>{e.stopPropagation(),n()},[n]);return r.a.createElement(C,{...l,onClick:o,disabled:i},e,t)},L=n(158),z=n(10);const I=Object(x.b)("li")`
  width: calc(var(--nav-size) * 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
`,T=Object(x.b)("a")`
  display: flex;
  align-items: center;
  justify-content: center;
  transition: filter 300ms;

  :hover {
    filter: brightness(.9);
  }

`,A=Object(x.b)("div")` 
  position: absolute;
  top: 58px;
  width: 300px;
  transform: translateX(-45%);
  background-color: var(--bg);
  border: var(--border);
  border-radius: var(--border-radius);
  padding: 1rem;
  transition: all var(--speed) ease;
  z-index: 99999;
  opacity: ${({state:e})=>"entered"===e?1:0};
  display: ${({state:e})=>"entered"===e?"block":"none"};
  a {
    color: var(--text-color);
    text-decoration: none;;
  }

`,_=Object(x.b)("div")` 
  width: 100%;
  display: flex;
  flex-direction: column;
  z-index: 99999;
  a:hover { 
    background-color: #525357;

  }
`,M=Object(x.b)(o.b)`
  height: 50px;
  display: flex;
  width: 100%;
  align-items: center;
  border-radius: var(--border-radius);
  transition: background var(--speed);
  padding: 0.5rem;
  cursor: pointer;
  .icon-button {
    margin-right: 0.5rem;
  }

  .icon-button:hover {
    filter: none;

  }

 

  .icon-right {
    margin-left: auto;
  }

`,N=({children:e})=>{const[t,n]=Object(a.useState)(!1);return r.a.createElement(I,null,r.a.createElement(T,{onClick:()=>n(!t)},r.a.createElement(z.m,{size:25})),r.a.cloneElement(e,{open:t,setOpen:n}))},D=({open:e,setOpen:t})=>{const{pathname:n}=Object(c.f)(),a=()=>{const e=document.getElementsByClassName("cl-accounts-manager-button");for(const n of e)n.addEventListener("click",()=>t(!1))},i=({children:e,leftIcon:t,rightIcon:n,onClick:a,to:i,state:l})=>r.a.createElement(M,{to:i,onClick:a,state:l},r.a.createElement("span",{className:"icon-button"},t),e,r.a.createElement("span",{className:"icon-right"},n));return r.a.createElement(L.a,{in:e,timeout:100},e=>r.a.createElement(A,{state:e},r.a.createElement(_,null,r.a.createElement(u.d,null,r.a.createElement(i,{onClick:a,leftIcon:r.a.createElement(u.f,{userProfileUrl:"/dashboard"}),to:n},"User Management")),r.a.createElement(u.e,null,r.a.createElement(i,{leftIcon:r.a.createElement(z.i,null),to:"/signin",state:{redirectPath:n},onClick:()=>t(!1)},"Sign In")))))},F=Object(x.b)("header")`
  width: 100%;
  height: var(--nav-size);
  padding: 0;
  margin: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-flow: row nowrap;
  background-color: transparent;
  box-shadow: 5px 5px 15px 5px #000000;
  border-bottom: 1px solid lightgrey;

  
`,P=Object(x.b)("img")`
    width: 3vw;
    height: 3vw;
  @media only screen and (max-width: 600px) {
    width: 8vw;
    height: 8vw;  
  }
  
`,U=Object(x.b)("div")`
  margin-left: 2vw;
  display: flex;
  width: 25vw;
  font-size: 1.2vw;
  @media only screen and (max-width: 600px) {
    font-size: 3.5vw;
  }
`;Object(x.b)("img")`
  --button-size: calc(var(--nav-size) * 0.5);
  width: var(--button-size);
  height: var(--button-size);
  border-radius: 50%;
  cursor: pointer; 
`;var $=()=>{const e=Object(c.g)();return r.a.createElement(F,null,r.a.createElement(U,null,r.a.createElement(S,{icon:r.a.createElement(P,{alt:"",src:"https://civil-dev.s3.us-west-1.amazonaws.com/assets/handshake.png"}),onClick:()=>e("/topics")},"Civil")),r.a.createElement(u.f,{userProfileUrl:"/dashboard"}),r.a.createElement(u.e,null,r.a.createElement(N,null,r.a.createElement(D,null))))},B=n(29),R=n(26),H=n(104);Object(x.b)("div")` 
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  padding: .5em .5em;    
  background-color: white;
  /* height: 4vw;
  max-height: 4vw; */
  transition: filter 1s ease-in-out;

  div {
    height: 100%;
    flex-grow: 1;
    display: flex;
    /* flex-direction: column; */
    /* justify-content: flex-end; */
    align-items: center;
    margin-left: 1em;
    background-color: white;
  }

  time {
      position: absolute;
      top: 1em;
      right: 1em;
      color: gray;
      font-size: .5em;
    }
  h3 {

    padding: .1em;
    font-size: .9em;
    margin: 0;
    border-top-left-radius: .5em;
    border-top-right-radius: .5em;
    font-weight: bold;
    color: gray;

  }
`;const Y=Object(x.b)("div")` 
  width: 100%;
  background-color: white;
  transition: all 1s ease-in-out;
  background-color: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  .twitter-tweet {
    max-width: 90%;
  }

`,V=Object(x.b)("p")` 
  width: 90%;
  padding: .5em 0;
  margin: 1em 0;
  font-size: 1.2vw;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  background-color: white;
  color: black;
  font-weight: bold;
  @media only screen and (max-width: 600px) {
    font-size: 5vw;

  }
  
`,X=(Object(x.b)("div")`
    background-color: white;
    display: flex;
    width: 100%;
    height: 1vw;
    padding-top: .4vw;
    justify-content: center;
    transition: filter 1s ease-in-out;
    svg {
      position: relative !important;
    }
`,Object(x.b)("li")` 
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: ${e=>e.height+"px"};
  width: 40vw;  
  margin: 2em 2em 2em 2em;
  border-radius: .5em;
  box-shadow:  -5px -5px 10px #5a5a5a, 5px 5px 10px #ffffff;
  border: none;
  cursor: pointer;
  overflow: hidden;
  text-decoration: none;
  transition: all 1s ease-in-out;

  @media only screen and (max-width: 600px) {
    width: 100%;
    border-radius: 0;
  }
 
`);Object(x.b)("img")` 
  flex-shrink: 0;
  width: 50px;
  height: 50px;      
  border-radius: 50%; 
`;var G=({children:e,summary:t,iconSrc:n,username:i,time:l,onClick:o,listCard:c,height:s})=>{const d=Object(a.useRef)(null),[m,u]=Object(a.useState)("unset");return Object(a.useEffect)(()=>{var e;const t=[...null==d||null===(e=d.current)||void 0===e?void 0:e.children].reduce((e,t)=>{const n=window.getComputedStyle(t).getPropertyValue("height");return e+Number(n.slice(0,n.length-2))},0);s&&u(t+s)},[d]),r.a.createElement(X,{ref:d,height:m,onClick:o,listCard:c},r.a.createElement(H.a,{iconSrc:n,time:l,username:i}),r.a.createElement(V,{className:"text-pop-up-top"},"“",t,"”"),r.a.createElement(Y,null,e))},Z=n(115),W=n(154);const K=Object(x.b)("ul")`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0;
  h2 {
    border-top: 1px solid gray;
    border-bottom: 1px solid gray;
    width: 100%;
    font-weight: bold;
    text-align: center;
  }
`,J=Object(x.b)("a")`
  display: block;
  text-decoration: none;
  color: black;
  font-weight: bold;
  margin: .3em 0;
`,q=new RegExp(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n\?\=]+)/im);var Q=({links:e,type:t})=>{const[n,i]=Object(a.useState)([!1,!1,!1]);return r.a.createElement(K,null,null==e?void 0:e.map((e,a)=>{const l=e.match(q);return r.a.createElement("div",{key:String(a)},r.a.createElement(J,{key:String(a),href:e,target:"_blank",id:`${t}-${e.slice(0,5)}-${a}`},l[1]),r.a.createElement(W.a,{autohide:!1,placement:"left",isOpen:n[a],target:`${t}-${e.slice(0,5)}-${a}`,toggle:()=>(e=>i(n.map((t,n)=>e===n?!t:t)))(a)},e))}))};const ee=Object(x.b)("div")`
  margin-top: 2em;
  display: flex;
`;var te=({showLinks:e,topic:t})=>r.a.createElement(ee,null,r.a.createElement(Q,{links:null==t?void 0:t.evidenceLinks,type:"evidence"}));const ne=x.b.div`
  display: flex;
  width: 100%;
  border-radius: .5em;
  justify-content: space-between;
  align-items: center;
  padding: 0 .5em;

  span {
    color: gray;
    font-size: .5em;
  }

  img {
    width: 1.5em;
    height: 1.5em;
    cursor: pointer;
    margin: .3em .5em;
  }
  svg {
    width: 1.5em !important;
    height: 1.5em  !important;
    margin: .3em .5em;

  }
`,ae=(Object(x.b)("span")``,({hideReplyIcon:e,likes:t,liked:n,updateLikes:a,onCommentClick:i,updateCivility:l,civil:o})=>{const c=null==o?1:-1,s=null==o?-1:1,d=o||!1===o;return r.a.createElement(ne,null,r.a.createElement("div",null,r.a.createElement(S,{icon:n?r.a.createElement(z.g,{color:"#F44336"}):r.a.createElement(z.h,null),onClick:a}),!e&&r.a.createElement(S,{icon:r.a.createElement(z.c,null),onClick:i}),r.a.createElement(S,{disabled:!1===o,icon:o?r.a.createElement("img",{alt:"",src:"https://civil-dev.s3.us-west-1.amazonaws.com/assets/handshake-clicked.png"}):r.a.createElement("img",{alt:"",src:"https://civil-dev.s3.us-west-1.amazonaws.com/assets/handshake.png"}),onClick:()=>l(c,d)}),r.a.createElement(S,{disabled:o,icon:!1===o?r.a.createElement("img",{alt:"",src:"https://civil-dev.s3.us-west-1.amazonaws.com/assets/no-handshake-clicked.png"}):r.a.createElement("img",{alt:"",src:"https://civil-dev.s3.us-west-1.amazonaws.com/assets/no-handshake.png"}),onClick:()=>l(s,d)})),r.a.createElement("div",null,r.a.createElement("span",null,t||0," ","likes")))});var re=Object(a.memo)(ae),ie=n(27);Object(x.b)("iframe")`
  height: 20vw;
  width: 100%;
`;const le=Object(x.b)("p")`
  width: 100%;
  font-size: 1vw;
  word-wrap: break-word;
  padding: 1em;

  @media only screen and (max-width: 600px) {
    font-size: 4vw;
  }
`;var oe=({showLinks:e,topic:t,onCommentClick:n,updateLikes:i})=>{const[l,o]=Object(a.useState)(!1),c=Object(a.useRef)(null);Object(ie.a)(c,null==t?void 0:t.description);const s=l?r.a.createElement(z.l,null):r.a.createElement(z.e,null);return r.a.createElement(r.a.Fragment,null,r.a.createElement(le,null,r.a.createElement("span",{ref:c})),e&&r.a.createElement(S,{icon:s,onClick:()=>o(!l)},"Show Additional Info"),r.a.createElement(Z.a,{in:l},r.a.createElement("div",null,r.a.createElement(te,{topic:t,showLinks:e}))),r.a.createElement(re,{liked:null==t?void 0:t.liked,likes:null==t?void 0:t.likes,onCommentClick:n,updateLikes:i}))},ce=(e,t)=>{const{updateTopicLikes:n}=Object(w.a)(R.a);return Object(a.useCallback)(()=>{n({id:null==e?void 0:e.id,userId:null==t?void 0:t.id,increment:!(null!=e&&e.liked)})},[e])},se=e=>{const t=Object(c.g)();return Object(a.useCallback)(()=>{t(`/topics/${e}/subtopics/`)},[e])};const de=new RegExp(/\b[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}\b/g);var me=e=>{var t;const{pathname:n}=Object(c.f)(),r=null===(t=n.match(de))||void 0===t?void 0:t[1],i=Object(s.b)(),{openModal:l}=Object(d.b)(y.b,i);return Object(a.useCallback)(()=>{l(B.d,{replyType:e,subtopicId:r})},[])},ue=n(28);const pe=Object(x.b)("div")`
  width: 100%;
  /* display: flex;
  flex-direction: column;
  align-items: center; */

  .twitter-tweet-rendered {
    margin: auto !important;
    /* width: 30vw; */
  }

`;Object(x.b)(re)` 
  /* position: absolute;
  bottom: 0; */
`,Object(x.b)("div")`
  width: 100%;
  margin-top: 2em;
  display: flex;
  ul:first-child {
    border-right: 1px solid gray;
  }
`,Object(x.b)("div")` 
  position: relative;
`,Object(x.b)("p")`
  width: 100%;
  font-size: .6em;
  word-wrap: break-word;
  padding: 1em;
`;var be=({topic:e,user:t,showLinks:n})=>{const i=Object(a.useRef)(null),l=me("TOPIC_REPLY"),o=ce(e,t),c=se(null==e?void 0:e.id),s=(e=>{const[t,n]=Object(a.useState)("unset");return Object(a.useEffect)(()=>{if(e.current){var t;null===(t=window.twttr.widgets)||void 0===t||t.load(e.current);const a=setInterval(()=>{var t;const r=null==e||null===(t=e.current)||void 0===t?void 0:t.querySelector("iframe");if(r){const e=window.getComputedStyle(r).getPropertyValue("height");"0px"!==e&&(n(""+Number(e.slice(0,e.length-2))),clearInterval(a))}},200)}},[e]),t})(i);return Object(a.useEffect)(()=>{var t;null!=e&&e.tweetHtml&&(i.current&&(i.current.innerHTML=(null==e||null===(t=e.tweetHtml)||void 0===t?void 0:t.toString())||"<span>Nothing</span>"))},[null==e?void 0:e.tweetHtml]),r.a.createElement(G,{onClick:c,username:null==e?void 0:e.createdBy,iconSrc:""+(null==e?void 0:e.createdByIconSrc),tweetRef:i,summary:null==e?void 0:e.summary,time:Object(ue.a)(null==e?void 0:e.createdAt),height:s},r.a.createElement(pe,{height:s,ref:i}," "),r.a.createElement(oe,{showLinks:n,topic:e,user:t,onCommentClick:l,updateLikes:o}))};const ge=Object(x.b)("iframe")`
  height: 20vw;
  width: 100%;
`;Object(x.b)("p")`
  width: 100%;
  font-size: .6em;
  word-wrap: break-word;
  padding: 1em;
`;var he=({topic:e,user:t,src:n,showLinks:i})=>{const l=Object(a.useRef)(null),o=se(null==e?void 0:e.id),c=ce(e,t);return Object(ie.a)(l,null==e?void 0:e.description),r.a.createElement(G,{onClick:o,username:null==e?void 0:e.createdBy,iconSrc:""+(null==e?void 0:e.createdByIconSrc),summary:null==e?void 0:e.summary,time:Object(ue.a)(null==e?void 0:e.createdAt)},r.a.createElement(ge,{src:n,loading:"lazy"}),r.a.createElement(oe,{topic:e,user:t,updateLikes:c,showLinks:i}))},fe=n(105),ve=n(42);var we=({topic:e,user:t,showLinks:n})=>{const i=Object(a.useRef)(null),l=(e=>{const[t,n]=Object(a.useState)(null);return Object(a.useEffect)(()=>{Object(ve.c)(null==e?void 0:e.contentUrl).then(({data:e})=>n(e))},[e]),t})(e),o=se(null==e?void 0:e.id),c=ce(e,t),s=me("TOPIC_REPLY");return Object(ie.a)(i,null==e?void 0:e.description),r.a.createElement(G,{onClick:o,username:null==e?void 0:e.createdBy,iconSrc:""+(null==e?void 0:e.createdByIconSrc),summary:null==e?void 0:e.summary,time:Object(ue.a)(null==e?void 0:e.createdAt)},l&&r.a.createElement(fe.a,{metaData:l}),r.a.createElement(oe,{showLinks:n,topic:e,user:t,onCommentClick:s,updateLikes:c}))};const xe=Object(x.b)("li")` 
  /* height: 20vw; */
  width: 40vw;
  overflow: hidden;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: white;
  color: black;
  margin: 2em;
  border-radius: .5em;
  cursor: pointer;
  box-shadow:  -5px -5px 10px #5a5a5a, 5px 5px 10px #ffffff;
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    z-index: 20;
    width: 50%;
    height: 100%;
    pointer-events: none;
  }
  transition: all .5s;
  :hover {
    transform: scale(1.1);
  }  

`,Ee=Object(x.b)("div")`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
`,ye=Object(x.b)("h2")`
  margin: 0;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
`,ke=Object(x.b)("div")`
  width: 100%;
`,Oe=(Object(x.b)("div")`
  width: 100%;
  .twitter-tweet {
    max-width: 15vw;
    max-height: 15vw;
  }

`,Object(x.b)("div")`
 position: absolute;
  bottom: 20px;
  right: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 52px;
  height: 52px;
  background: rgb(252,163,17);
  background: #B9314F;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(#000000, 0.2);
  transition: 0.5s;
  cursor: pointer;
  padding: 5px;

  
  &::before {
    content: "Info";
    font-size: 12px;
    text-transform: uppercase;
    font-weight: 850;
    letter-spacing: 0.02em;
  }
  
  &:hover,
  &:focus {
    border-radius: 2.5em !important;
    bottom: 0;
    right: 0;
    width: 101%;
    height: 101%;
    box-shadow: none;
    border-radius: 0;    
    &::before {
      content: none;
    }
  }

`),je=Object(x.b)("div")`
  z-index: 1;
  padding: 20px;
  line-height: 1.4;
  opacity: 0;
  visibility: hidden;
  box-sizing: border-box;
  pointer-events: none;
  transition: 0s;
  
  ${Oe}:hover ~ & {
    opacity: 1;
    visibility: visible;
    transition: 0.2s 0.3s;
  }
  
  h2 {
    margin: 0;
    margin-bottom: 16px;
  }
`;var Ce=({topic:e,user:t})=>{const n=Object(c.g)();return e.ytUrl?r.a.createElement(he,{topic:e,user:t,showLinks:!1,src:e.ytUrl.replace("watch?v=","embed/")}):e.tweetHtml?r.a.createElement(be,{topic:e,user:t,showLinks:!1}):e.contentUrl?r.a.createElement(we,{topic:e,user:t,showLinks:!1}):r.a.createElement(xe,{onClick:()=>n(`/topics/${e.id}/subtopics/`)},r.a.createElement(Ee,{className:"card__frame"},r.a.createElement(ye,{className:"card__title"},e.title,r.a.createElement(ke,null)),r.a.createElement(Oe,{className:"card__overlay"}),r.a.createElement(je,{className:"card__content"},r.a.createElement("h2",null,e.title),r.a.createElement("p",null,e.description))))},Se=n(44);const Le=Object(x.b)("div")` 
  width: 100%;
  border-bottom: 1px solid gray;
  padding: 2vw 0;
  display: flex;
  justify-content: center;
  align-items: center;

  p {
    margin: 0 1vw;
    font-size: 1.1vw;
    color: gray
  }
`,ze=Object(x.b)("img")`  
  flex-shrink: 0;
  width: 3vw;
  height: 3vw;      
  border-radius: 50%; 
`,Ie=Object(x.b)("div")`  
  flex-wrap: wrap;
  flex-direction: column;
  display: flex;
`;var Te=({user:e,openModal:t})=>(console.log(""),r.a.createElement(Le,null,r.a.createElement(ze,{src:(null==e?void 0:e.iconSrc)||"https://civil-dev.s3.us-west-1.amazonaws.com/profile_img_1.png"}),r.a.createElement(Ie,null,r.a.createElement("p",{className:"text-focus-in"},"Hey"," ",r.a.createElement("b",null,(null==e?void 0:e.username)||"Friend"),"! ","Have Something You Would Like To Discuss?"),r.a.createElement(Se.a,{type:"button",onClick:()=>t(B.b),width:"100%"},"Create Topic +"))));const Ae=Object(x.b)("div")`
  position: fixed;
  width: 100vw;
  top: ${e=>e.top?e.top:"50%"};
  z-index: 1;
`,_e=Object(x.b)("div")` 
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
`,Me=Object(x.b)("div")` 
  position: absolute;
  bottom: 0;
  transform: rotate(180deg) translateY(-99%) ;
  width: 100vw;
`;var Ne=({color:e,top:t})=>r.a.createElement(Ae,{top:t},r.a.createElement(_e,null,r.a.createElement("svg",{width:"100%",height:"100%",id:"svg",viewBox:"0 0 1440 400",xmlns:"http://www.w3.org/2000/svg",className:"transition duration-300 ease-in-out delay-150"},r.a.createElement("path",{d:"M 0,400 C 0,400 0,133 0,133 C 109.53571428571428,145.71428571428572 219.07142857142856,158.42857142857142 344,153 C 468.92857142857144,147.57142857142858 609.25,124.00000000000001 738,110 C 866.75,95.99999999999999 983.9285714285716,91.57142857142858 1099,97 C 1214.0714285714284,102.42857142857142 1327.0357142857142,117.71428571428571 1440,133 C 1440,133 1440,400 1440,400 Z",stroke:"none",strokeWidth:"0",fill:"#222629",className:"transition-all duration-300 ease-in-out delay-150 path-0"}),r.a.createElement("path",{d:"M 0,400 C 0,400 0,266 0,266 C 113.75,253.60714285714286 227.5,241.21428571428572 349,244 C 470.5,246.78571428571428 599.7499999999999,264.75 737,260 C 874.2500000000001,255.25 1019.5000000000002,227.7857142857143 1138,225 C 1256.4999999999998,222.2142857142857 1348.25,244.10714285714283 1440,266 C 1440,266 1440,400 1440,400 Z",stroke:"none",strokeWidth:"0",fill:"rgb(97,137,48)",className:"transition-all duration-300 ease-in-out delay-150 path-1"}))),r.a.createElement(Me,null,r.a.createElement("svg",{width:"100%",height:"100%",id:"svg",viewBox:"0 0 1440 400",xmlns:"http://www.w3.org/2000/svg",className:"transition duration-300 ease-in-out delay-150"},r.a.createElement("path",{d:"M 0,400 C 0,400 0,133 0,133 C 109.53571428571428,145.71428571428572 219.07142857142856,158.42857142857142 344,153 C 468.92857142857144,147.57142857142858 609.25,124.00000000000001 738,110 C 866.75,95.99999999999999 983.9285714285716,91.57142857142858 1099,97 C 1214.0714285714284,102.42857142857142 1327.0357142857142,117.71428571428571 1440,133 C 1440,133 1440,400 1440,400 Z",stroke:"none",strokeWidth:"0",fill:"#222629",className:"transition-all duration-300 ease-in-out delay-150 path-0"}),r.a.createElement("path",{d:"M 0,400 C 0,400 0,266 0,266 C 113.75,253.60714285714286 227.5,241.21428571428572 349,244 C 470.5,246.78571428571428 599.7499999999999,264.75 737,260 C 874.2500000000001,255.25 1019.5000000000002,227.7857142857143 1138,225 C 1256.4999999999998,222.2142857142857 1348.25,244.10714285714283 1440,266 C 1440,266 1440,400 1440,400 Z",stroke:"none",strokeWidth:"0",fill:"rgb(97,137,48)",className:"transition-all duration-300 ease-in-out delay-150 path-1"}))));const De=Object(x.b)("div")`
  width: 100vw;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  z-index: 9999;
  /* padding-top: 5em; */
`,Fe=Object(x.b)("div")`
  width: 50vw;
  border: 1px solid gray;
  z-index: 9999;
  background-color: white;

`,Pe=(Object(x.b)("p")` 
  display: flex;
  flex-direction: column;
  padding: 1em 2em;
  border-radius: 1em;
  font-weight: bold;
  text-transform: capitalize;
  border: 1px solid black;
  box-shadow:  5px 5px 4px #5a5a5a,
             -5px -5px 4px #ffffff;
  b {
    color: var(--m-primary-color)
  }
`,Object(x.b)("ul")`
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-wrap: wrap;
  z-index: 9999;
  padding: 0;
  margin: 5em 0 0 0;
  padding-bottom: 30vh;
  background-color: #F0F2F5;
  background-color: white;

`);var Ue=()=>{const{openModal:e,getAllTopics:t}=Object(w.a)(y.b,R.a),n=Object(s.c)(e=>e.topics.list)||[],i=Object(s.c)(e=>e.session.currentUser);return Object(a.useEffect)(()=>{t()},[]),r.a.createElement(r.a.Fragment,null,r.a.createElement(De,null,r.a.createElement(Fe,null,r.a.createElement(Te,{user:i,openModal:e}),r.a.createElement(Pe,null,n.map(e=>r.a.createElement(Ce,{key:e.id,topic:e,user:i})))),r.a.createElement(Ne,{color:"#EF5D45",top:"100%"})))},$e=n(69);const Be=Object(x.b)("div")`
  width: 100vw;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  /* padding-top: 5em; */

  .tab-content {
   padding-bottom: 40vh;
 }
`,Re=(Object(x.b)("ul")`
  display: flex;
  flex-wrap: wrap;
  width: 85vw;
`,Object(x.b)("hr")` 
  width: 90%;
  margin: 1em 0 2em 0;
  background-color: rgb(48,48,50);
  height: .5px;
  border: none;
`),He=Object(x.b)("div")` 
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 1em;
  /* border: 1px solid gray; */
  /* border-top: none; */
  padding-top: 5em;
  z-index: 99;
  background-color: #F7F7F7;
  background-color: white;
  h1 {
    text-align: center;
    text-decoration: underline;
    letter-spacing: .2em;
    font-weight: bold;
  }

   @media only screen and (max-width: 600px) {
    padding: 1em 0;
  }

`;Object(x.b)("div")`
  width: 100%;
  margin-top: 2em;
  display: flex;
  ul:first-child {
    border-right: 1px solid gray;
  }
`;const Ye=Object(x.b)("iframe")`
  width: 70.8vw;
  height: 40vw;

`,Ve=Object(x.b)("p")`
  width: 100%;
  font-size: .6em;
  word-wrap: break-word;
  padding: 1em;
`,Xe=Object(x.b)("div")` 
  position: relative;
`;var Ge=({topic:e,user:t,src:n,showLinks:i})=>{const l=Object(a.useRef)(null),[o,c]=Object(a.useState)(!1),s=me("TOPIC_REPLY"),d=se(e.id),{updateTopicLikes:m}=Object(w.a)(R.a),u=((e,t,n)=>Object(a.useCallback)(()=>{t&&n&&e({id:t.id,userId:n.id,increment:!t.liked})},[t]))(m,e,t);Object(ie.a)(l,null==e?void 0:e.description);const p=o?r.a.createElement(z.l,null):r.a.createElement(z.e,null);return r.a.createElement(r.a.Fragment,null,r.a.createElement(Ye,{src:n}),r.a.createElement(G,{onClick:d,username:null==e?void 0:e.createdBy,iconSrc:""+(null==e?void 0:e.createdByIconSrc),summary:null==e?void 0:e.summary,time:Object(ue.a)(null==e?void 0:e.createdAt)},r.a.createElement(Ve,null,r.a.createElement("span",{ref:l})),0!==(null==e?void 0:e.evidenceLinks.length)&&r.a.createElement(Xe,null,r.a.createElement(S,{icon:p,onClick:()=>c(!o)},"Show Additional Info")),r.a.createElement(Z.a,{in:o},r.a.createElement("div",null,r.a.createElement(te,{topic:e,showLinks:i}))),r.a.createElement(re,{liked:null==e?void 0:e.liked,likes:null==e?void 0:e.likes,onCommentClick:s,updateLikes:u})))};var Ze=({topic:e,user:t})=>{let n=null;return n=null!=e&&e.tweetHtml?r.a.createElement(be,{topic:e,user:t,showLinks:!0}):null!=e&&e.ytUrl?r.a.createElement(Ge,{topic:e,user:t,showLinks:!0,src:e.ytUrl.replace("watch?v=","embed/")}):r.a.createElement(we,{topic:e,user:t,showLinks:!0}),r.a.createElement(He,null,r.a.createElement("h1",{className:"text-focus-in"}," ","We're Talking About..."),n)},We=n(159);const Ke=new Set(["POSITIVE","NEUTRAL","NEGATIVE"]);var Je=n(51);const qe=Object(x.b)("li")`
  width: 100%;
  outline: none;
  border-radius: .4em;
  list-style: none;
  margin-top: 1em;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: white;
  :hover {
    /* opacity: .9; */
    /* filter: brightness(.9); */
    /* background-color: #ef5d4566; */
    background-color: #D8FFF1;
  }

   @media only screen and (max-width: 600px) {
    width: 100%;
    border-radius: 0;
  }
`,Qe=Object(x.b)("div")`
  display: flex;
  width: 100%;
  padding: 1em;
  border-bottom: 1px solid gray;
  justify-content: space-between;
  align-items: center;
`,et=Object(x.b)("b")` 
  color: black;
`,tt=Object(x.b)("time")` 
  color: gray;
`,nt=Object(x.b)("div")`
  position: relative;
  color: black;
  min-height: 10vh;
  padding: 1em;
  width: 100%;
`,at=Object(x.b)("img")` 
  flex-shrink: 0;
  width: 50px;
  height: 50px;      
  border-radius: 50%; 
`,rt=Object(x.b)("div")` 
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translate(-50%);
`,it=Object(x.b)("ul")` 
  background-color: #F0F2F5;
  width: 100%;
  word-break: break-all;
  padding: 0 .5em .5em .5em;
  display: flex;
  flex-direction: column;
`,lt=Object(x.b)("p")` 
  padding: 1em;
`;const ot=({commentData:e,replies:t})=>{if(!e)return null;const n=r.a.useContext(dt),i=Object(a.useRef)(null),[l,o]=Object(a.useState)(!1),c=Object(s.c)(e=>e.session.currentUser),m=((e,t)=>{const n=!e.liked,r=Object(s.b)(),{updateCommentLikes:i}=Object(d.b)(Je.a,r);return Object(a.useCallback)(()=>{i({id:e.id,userId:null==t?void 0:t.id,increment:n})},[e.liked])})(e,c),u=((e,t)=>{const n=Object(s.b)(),{openModal:r}=Object(d.b)(y.b,n);return Object(a.useCallback)(()=>{r(B.d,{replyType:"COMMENT_REPLY",commentId:e,rootParentCommentId:t})},[])})(e.id,n),p=(e=>{const t=Object(s.b)(),{updateCommentCivility:n}=Object(d.b)(Je.a,t);return Object(a.useCallback)((t,a)=>{n({userId:e.createdById,commentId:e.id,civility:t,removeCivility:a})},[e.civil])})(e);Object(ie.a)(i,null==e?void 0:e.content);const b=Object(ue.a)(e.createdAt),g=l?r.a.createElement(z.l,null):r.a.createElement(z.e,null);return r.a.createElement(qe,null,r.a.createElement(Qe,null,r.a.createElement(at,{src:e.createdByIconSrc}),r.a.createElement(et,null,e.createdBy),r.a.createElement(tt,null,""+b)),r.a.createElement(nt,null,r.a.createElement(lt,{ref:i}),0!==t.length&&r.a.createElement(rt,null,r.a.createElement(S,{icon:g,onClick:()=>o(!l)},"Replies"))),r.a.createElement(re,{likes:e.likes,liked:e.liked,updateLikes:m,onCommentClick:u,updateCivility:p,civil:e.civil}),r.a.createElement(Z.a,{in:l},r.a.createElement(it,null,t.map((t,n)=>r.a.createElement(ot,{key:e.id+String(n),commentData:t.data,replies:t.children})))))};var ct=Object(a.memo)(ot);const st=Object(x.b)("ul")`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 2em;
  margin: 0;
  padding: 0;
  /* border-left: 1px solid black;
  border-right: 1px solid black; */
  z-index: 99;
  opacity: .99;
  width: 70vw;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;


  h1 {
    display: flex;
    width: 100%;
    align-items: center;
    font-weight: bold;
    padding: 1em;
    font-size: 1vw;
    border-bottom: 1px solid black;
    color: white;
    border: none;
    outline: none;
    background-color: ${e=>e.color};
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;

     @media only screen and (max-width: 600px) {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
      font-size: 5vw;

    }
  }

  
   @media only screen and (max-width: 600px) {
    width: 100%;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
`,dt=r.a.createContext(null);var mt=({comments:e,commentSentiment:t,color:n})=>r.a.createElement(st,{color:n},r.a.createElement("h1",null,e.length," ",t," ","Comments"),null==e?void 0:e.map(e=>{var n,a;return r.a.createElement(dt.Provider,{key:(null===(n=e.data)||void 0===n?void 0:n.id)+t,value:null===(a=e.data)||void 0===a?void 0:a.id},r.a.createElement(ct,{commentData:e.data,replies:e.children}))}));Object(x.b)("div")`
  width: 100vw;
  height: 50vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 5em;

  header {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 1.5em;
    background-color: var(--m-primary-background-color);
    border-radius: 1em;
    h1 {
      max-width: 30vw;
    }
    b {
     color: var(--m-primary-color)
    }
  }
`;const ut=Object(x.b)("section")`
  display: flex;
  justify-content: space-evenly;
  /* border-top: 1px solid gray; */
  width: 100vw;

  ul:first-child {
    /* border-right: .1px dashed rgb(48,48,50); */
  }

   ul:last-child {
    /* border-left: .1px solid rgb(48,48,50); */
  }


`;var pt=n(157);const bt=Object(x.b)(pt.a)`
  z-index: 9999;

  li {
    border-radius: .5em;
    background-color: white;
    margin: .5em;
    @media only screen and (max-width: 600px) {
      /* margin: 0; */
    }
  }

  .active {
    border-radius: .5em;
    box-shadow: inset 1px 2px 5px #777;
  }

 .nav-link {
   color: black;
   font-weight: bold;
    @media only screen and (max-width: 600px) {
      font-size: 3vw;
      padding: .5rem .9rem;
      
    }
 }

`;var gt=()=>{const{subTopicId:e,topicId:t}=Object(c.h)(),{getSubTopic:n,getAllComments:i,getTopic:l}=Object(w.a)($e.a,Je.a,R.a),o=Object(s.c)(e=>e.session.currentUser),[d,m]=Object(a.useState)("neutral"),{POSITIVE:u,NEUTRAL:p,NEGATIVE:b,all:g}=(()=>{const e=Object(s.c)(e=>e.comments.list);return Object(a.useMemo)(()=>{const t={POSITIVE:[],NEUTRAL:[],NEGATIVE:[],all:e};return e.forEach(e=>{var n,a;Ke.has(null===(n=e.data)||void 0===n?void 0:n.sentiment)&&t[null===(a=e.data)||void 0===a?void 0:a.sentiment].push(e)}),t},[e])})();return Object(a.useEffect)(()=>{o&&(n(e),i(e,null==o?void 0:o.id),l(t,null==o?void 0:o.id))},[o]),r.a.createElement(r.a.Fragment,null,r.a.createElement(Re,null),r.a.createElement(bt,{activeKey:d,onSelect:e=>m(e)},r.a.createElement(We.a,{eventKey:"all",title:"All"},r.a.createElement(ut,null,r.a.createElement(mt,{comments:g,commentSentiment:"",color:"var(--m-primary-background-2-color)"}))),r.a.createElement(We.a,{eventKey:"positive",title:"Generally Positive"},r.a.createElement(ut,null,r.a.createElement(mt,{comments:u,commentSentiment:"Generally Positive",color:"#6A6E70"}))),r.a.createElement(We.a,{eventKey:"neutral",title:"Neutral"},r.a.createElement(ut,null,r.a.createElement(mt,{comments:p,commentSentiment:"Neutral",color:"#474A4F"}))),r.a.createElement(We.a,{eventKey:"negative",title:"Generally Negative"},r.a.createElement(ut,null,r.a.createElement(mt,{comments:b,commentSentiment:"Generally Negative",color:"var(--m-primary-color)"})))))};const ht=Object(x.b)("div")` 

  display: flex;
  flex-direction: column;
  align-items: center;
  width: 90%;
  box-shadow: 0 0 40px -10px rgba(0, 0, 0, .4);


`,ft=Object(x.b)("header")` 
    height: 10vh;
    background-image: linear-gradient(to right, var( --m-primary-background-1-color), #83af9b);
    color: #fff;
    position: relative;
    /* border-radius: 12px 12px 0 0; */
    overflow: hidden;
    width: 100%;
    /* border-radius: 12px; */
    h1 {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 2;
      margin: 0;
      
      span {
        display: block;
      }
      
      span:first-child {
        font-size: 1.5vw;
        font-weight: 700;
        letter-spacing: 6.5px;
      }
      
      span:last-child {
        font-size: .8vw;
        font-weight: 500;
        letter-spacing: 3.55px;
        opacity: .85;
        transform: translateY(-2px);
      }
    }
    
    .leaderboard__icon {
      fill: #fff;
      opacity: .35;
      width: 50px;
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
    }
`,vt=Object(x.b)("table")` 
  border-radius: 0 0 12px 12px;
  padding: 15px 15px 20px;
  display: grid;
  row-gap: 8px;
  width: 100%;
  
`,wt=Object(x.b)("tr")`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  align-items: center;
  padding: 10px 30px 10px 10px;
  background-color: var(--bg-accent);
  border-radius: .5vw;

`,xt=Object(x.b)("th")`
  color: white;
  font-weight: bold;
  letter-spacing: .1vw;
  font-size: 20px;


`,Et=Object(x.b)("tr")` 
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    align-items: center;
    padding: 10px 30px 10px 10px;
    overflow: hidden;
    border-radius: .5vw;
    box-shadow: 0 5px 7px -1px rgba(51, 51, 51, 0.23);
    cursor: pointer;
    transition: transform .25s cubic-bezier(.7,.98,.86,.98), box-shadow .25s cubic-bezier(.7,.98,.86,.98);
    background-color: #fff;
    
    &:hover {
      transform: scale(1.2);
      box-shadow: 0 9px 47px 11px rgba(51, 51, 51, 0.18);
    }
  
  /* &__picture {
    max-width: 100%;
    width: 60px;
    border-radius: 50%;
    box-shadow: 0 0 0 10px #ebeef3, 0 0 0 22px #f3f4f6;
  } */
  
`,yt=Object(x.b)("td")` 
  /* opacity: .8; */
  font-weight: 600;
  color: #979cb0;
  font-weight: 600;
  font-size: 20px;
  letter-spacing: .1vw;    

`;var kt=({id:e,title:t,createdBy:n,createdAt:i,topicId:l})=>{const o=((e,t)=>{const n=Object(c.g)();return Object(a.useCallback)(()=>{n(`/topics/${e}/subtopics/${t}`)},[])})(l,e);return r.a.createElement("tbody",null,r.a.createElement(Et,{onClick:o},r.a.createElement(yt,null,n),r.a.createElement(yt,null,t),r.a.createElement(yt,null,i)))};var Ot=()=>{const e=Object(s.c)(e=>e.subtopics.list),{topicId:t}=Object(c.h)();return r.a.createElement(r.a.Fragment,null,r.a.createElement(Re,null),r.a.createElement(ht,null,r.a.createElement(ft,null,r.a.createElement("h1",null,r.a.createElement("span",null,"Covid"),r.a.createElement("span",null,"Sub Topics"))),r.a.createElement(vt,null,r.a.createElement("thead",null,r.a.createElement(wt,null,r.a.createElement(xt,null," Created By "),r.a.createElement(xt,null," Title "),r.a.createElement(xt,null," Description "),r.a.createElement(xt,null," Comments "))),e.map(e=>r.a.createElement(kt,{key:t,...e,topicId:t})))))};const jt=Object(x.b)("section")`

  width: 70vw;
  padding-bottom: 20vh;
  display: flex;
  flex-direction: column;
  align-items: center;

   > h1 {
    padding: .5em 2em;
    border-radius: 2em;
    margin-bottom: 2vw;
    box-shadow:  -5px -5px 10px #5a5a5a, 5px 5px 10px #ffffff;
  }
  b {
    color: var(--m-primary-color);
  }
`;var Ct=()=>{const e=Object(s.c)(e=>e.subtopics.list),t=Object(s.b)(),{openModal:n}=Object(d.b)(y.b,t),i=null==e?void 0:e.find(({title:e})=>"General"===e),l=(e=>{const t=Object(c.g)();return Object(a.useCallback)(()=>t(e),[e])})(null==i?void 0:i.id);return r.a.createElement(jt,null,r.a.createElement("h1",null,"Browse Some"," ",r.a.createElement("b",null,"Sub-Topics")," ","or Create Your Own..."),r.a.createElement("div",{style:{display:"flex"}},r.a.createElement(Se.a,{type:"button",onClick:()=>n(B.a)},"Create Sub Topic +"),r.a.createElement(Se.a,{type:"button",onClick:l},"General Discussion"," ",r.a.createElement(z.k,{size:50}))),r.a.createElement(Ot,null))},St=()=>r.a.createElement(c.d,null,r.a.createElement(c.b,{path:":subTopicId",element:r.a.createElement(r.a.Fragment,null,r.a.createElement(Ne,{color:"green",top:"115%"}),r.a.createElement(gt,null))}),r.a.createElement(c.b,{path:"/",element:r.a.createElement(Ct,null)}));var Lt=()=>{var e;const{topicId:t}=Object(c.h)(),{getAllSubTopics:n,getTopic:i}=Object(w.a)($e.a,R.a),l=null===(e=Object(s.c)(e=>e.topics.list))||void 0===e?void 0:e.find(e=>e.id===t),o=Object(s.c)(e=>e.session.currentUser);return Object(a.useEffect)(()=>{i(t,null==o?void 0:o.id),n(t)},[]),r.a.createElement(Be,null,r.a.createElement(Ze,{topic:l,user:o}),r.a.createElement(Re,null),r.a.createElement(St,null))},zt=n(156),It=n(155);const Tt=Object(x.b)("div")` 
  height: 100%;
  width: 12vw;
  max-width: ${e=>e.isOpen?"12vw":"2vw"};
  background-color: var(--m-menu-bg-color);
  box-shadow: var(--m-primary-box-shadow);
  transition: max-width .6s ease-in-out;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  color: white;
  font-weight: bold;
  position: absolute;
  z-index: 99999;
  left: 0;
  flex: 0 0 12vw;

  .container {
    display: flex !important;
    justify-content: flex-end;
    margin-bottom: 1em;
    padding-top: 1em;
    padding-bottom: 1em;
    border-bottom: 1px solid black;
  }
  svg {
    cursor: pointer;
    border-radius: .3em;
    margin: .2em;
  }

  @media only screen and (max-width: 600px) {
    display: none;
  }

`,At=Object(x.b)("nav")` 
  display: flex;
  flex-direction: column;
  margin: 0;
  padding: 0;
  width: 100%;
  align-items: center;
  z-index: 9999999;
  button {
    width: 90%;
    margin: 0;
    border-radius: var(--border-radius);
    padding: 5%;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    cursor: pointer;
    outline: none;
    background: none;
    border: none;
    color: white;
  }

  button:hover {
    background-color: var(--bg-accent);
  }

  

`;var _t=()=>{const e=Object(c.g)(),[t,n]=Object(a.useState)(!1);return r.a.createElement(Tt,{isOpen:t},r.a.createElement(zt.a,{placement:"right",overlay:r.a.createElement(W.a,null,r.a.createElement("strong",null,t?"Collapse":"Expand"))},r.a.createElement(It.a,null,t?r.a.createElement(z.a,{onClick:()=>n(!t)}):r.a.createElement(z.b,{onClick:()=>n(!t)}))),r.a.createElement(At,null,r.a.createElement("button",{type:"button",onClick:()=>e("/dashboard")},r.a.createElement(z.m,null),t&&"Profile"),r.a.createElement("button",{type:"button"},r.a.createElement(z.j,null),t&&"Notifications")))};const Mt=x.c`

  0% {
    transform: rotateZ(0deg);
  }
  100% {
    transform: rotateZ(360deg);
  }
}
`,Nt=Object(x.b)("div")`
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 0;
  z-index: 999999999;
  background-color: rgba(0, 0, 0, .6);
  opacity: .99;
`,Dt=Object(x.b)("div")` 
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  transform: scale(2);

.dot-overtaking {
  transform: scale(2);
  position: relative;
  z-index: 9999999999;
  width: 12px;
  height: 12px;
  border-radius: 6px;
  background-color: transparent;
  color: #fff;
  margin: -1px 0;
  box-shadow: 0 -20px 0 0;
  animation: ${Mt} 2s infinite cubic-bezier(.2, .6, .8, .2);

  &::before,
  &::after {
    content: '';
    display: inline-block;
    position: absolute;
    top: 0;
    left: 0;

    width: 12px;
    height: 12px;
    border-radius: 6px;
    background-color: transparent;
    color: #fff;
    box-shadow: 0 -20px 0 0;
  }

  &::before {
    animation: ${Mt} 2s infinite cubic-bezier(.2, .6, .8, .2);
    animation-delay: .3s;
  }

  &::after {
    animation: ${Mt} 1.5s infinite cubic-bezier(.2, .6, .8, .2);
    animation-delay: .6s;
  }
}




`;var Ft=()=>{const e=Object(s.c)(e=>e.ui.loadingSpinner.isOpen);return r.a.createElement(r.a.Fragment,null,e&&r.a.createElement(Nt,null,r.a.createElement(Dt,null,r.a.createElement("div",{className:"dot-overtaking"}))))};const Pt=x.b.main`
  display: flex;
  width: 100vw;
  height: calc(100vh - var(--nav-size));
  margin: 0;
  padding: 0;

`,Ut=Object(x.b)("div")`
  flex-grow: 1;
  overflow-y: scroll;
  overflow-x: hidden;
`,$t=r.a.lazy(()=>n.e(2).then(n.bind(null,307))),Bt=()=>((()=>{const e=Object(s.b)(),{user:t}=Object(u.h)({withAssertions:!0}),{getAllEnums:n,getCurrentUser:r}=Object(w.a)(f,v.b);Object(a.useEffect)(()=>{n()},[]),Object(a.useEffect)(()=>{t&&(t.iconSrc=t.profileImageUrl,e(Object(v.a)(t)),r(null==t?void 0:t.id))},[t])})(),r.a.createElement(r.a.Fragment,null)),Rt=({children:e})=>{const{user:t,isLoading:n}=Object(u.h)({withAssertions:!0});return r.a.createElement(r.a.Fragment,null,n(t)?null:r.a.createElement(r.a.Fragment,null,r.a.createElement(Bt,null),e))},Ht=Object(m.b)({enter:"slide-in-elliptic-top-fwd",exit:"slide-out-elliptic-bottom-bck"}),Yt=()=>{const e=Object(c.g)(),t=Object(a.useCallback)(t=>e(t)),n=Object(s.b)(),{closeModal:i}=Object(d.b)(y.b,n);return r.a.createElement(u.a,{frontendApi:"clerk.bjuk3.m71w1.lcl.dev",navigate:t},r.a.createElement(E,null),r.a.createElement(Rt,null,r.a.createElement("div",{id:"main-container",style:{width:"100vw",height:"100vh",overflow:"hidden"}},r.a.createElement(Ft,null),r.a.createElement($,null),r.a.createElement(Pt,null,r.a.createElement(_t,null),r.a.createElement(Ut,null,r.a.createElement(c.d,null,r.a.createElement(c.b,{path:"/topics/:topicId/subtopics/*",element:r.a.createElement(Lt,null)}),r.a.createElement(c.b,{path:"/dashboard",element:r.a.createElement(a.Suspense,{fallback:r.a.createElement("div",null,"Loading...")},r.a.createElement($t,null))}),r.a.createElement(c.b,{path:"/signin",element:r.a.createElement(O,null)}),r.a.createElement(c.b,{path:"/signup",element:r.a.createElement(j,null)}),r.a.createElement(c.b,{path:"/topics/*",element:r.a.createElement(Ue,null)}),r.a.createElement(c.b,{path:"/",element:r.a.createElement(c.a,{replace:!0,to:"/topics"})}))),r.a.createElement(B.e,{closeModal:i}),r.a.createElement(m.a,{autoClose:2e3,className:"toasty",transition:Ht})))))};var Vt=Object(a.memo)(Yt),Xt=n(112),Gt=n(113),Zt=n.n(Gt),Wt=n(48),Kt=n(35),Jt=n(57),qt=n(65),Qt=n(47);const en=new Map([["ADD_USER",(e,t)=>{const n=t.list.findIndex(t=>t.id===e.payload.id);return-1!==n?{...t,list:[...t.list.filter((e,t)=>t!==n),e.payload]}:{...t,list:[...t.list,e.payload]}}]]);var tn=(e={list:[]},t)=>en.has(t.type)?en.get(t.type)(t,e):e;var nn=Object(d.c)({session:Wt.e,ui:Kt.d,topics:Jt.d,subtopics:qt.c,comments:Qt.e,enums:p,users:tn});var an=(e={})=>Object(d.d)(nn,e,Object(d.a)(Xt.a,Zt.a));n(145);document.addEventListener("DOMContentLoaded",()=>{const e=document.getElementById("root"),t=an({session:{currentUser:null}});l.a.render(r.a.createElement(s.a,{store:t},r.a.createElement(o.a,null,r.a.createElement(c.d,null,r.a.createElement(c.b,{path:"/*",element:r.a.createElement(Vt,null)})))),e)})},20:function(e,t,n){"use strict";var a=n(3),r=n(14);t.a=(...e)=>{const t=Object(a.b)(),n=e.reduce((e,t)=>({...e,...t}),{});return Object(r.b)(n,t)}},26:function(e,t,n){"use strict";var a=n(11),r=n(57),i=n(42);const l=e=>({type:r.a,payload:e});t.a={createTopic:e=>t=>{t(a.d),i.a(e).then(e=>t(l(e.data))).then(()=>t(Object(a.a)())).finally(Object(a.c)(t))},getAllTopics:()=>e=>i.b().then(t=>{return e((n=t.data,{type:r.b,payload:n}));var n}),getTopic:(e,t)=>n=>i.d(e,t).then(e=>n(l(e.data))),updateTopicLikes:e=>t=>i.e(e).then(e=>t((e=>({type:r.c,payload:e}))(e.data))),uploadTopicMedia:(e,t,n)=>r=>i.f(e,t,n).then(e=>r(l(e.data))).then(()=>r(Object(a.a)()))}},27:function(e,t,n){"use strict";var a=n(0);t.a=(e,t)=>{Object(a.useEffect)(()=>{null!=e&&e.current&&(e.current.innerHTML=t)},[e,t])}},28:function(e,t,n){"use strict";n.d(t,"a",(function(){return a}));const a=e=>{let t,n="m";const a=Date.now(),r=new Date(e);return t=Math.floor((a-r)/6e4),t>60&&(t=Math.floor(t/60),n="h"),t>60&&(t=Math.floor(t/24),n="d"),`${t}${n}`}},29:function(e,t,n){"use strict";n.d(t,"b",(function(){return C})),n.d(t,"a",(function(){return S})),n.d(t,"d",(function(){return L})),n.d(t,"c",(function(){return z}));var a=n(0),r=n.n(a),i=n(45),l=n(3),o=n(1);Object(o.b)("button")`
  position: absolute;
  top: .2vw;
  right: .2vw; 
  border-radius: 5px;
  background-color: transparent;
  font-size: 1em;
  font-weight: bolder;
  border: none;
  outline: none;
  cursor: pointer;
  transition: filter .2s linear;
  :hover {
    filter: drop-shadow(0 2px 12px black) brightness(.8);

  }
`;const c=Object(o.b)("div")` 
.modal-header {
  border-bottom: 1px solid black;
  }

.modal-title {
  font-weight: bold;
  font-size: 1.5em;
}

.modal-footer {
  border-top: 1px solid black;
  width: 100%;
  padding-top: 1.5em;
  margin-top: 1.5em;
}
`;var s=n(49);const d=Object(o.b)("label")` 
  background-image: ${e=>`url(${e.iconSrc})`};
  background-position: center no-repeat;
  background-size: cover;

  height: 3em;
  width: 3em;
  border-radius: 50%;
  margin: .5em;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
`,m=Object(o.b)("input")`
  display: none;
  &:checked + ${d} {
    /* background-image: ${e=>`url(${e.iconSrc})`}; */
    border: 1px solid black;
  }
`;var u=({width:e,field:t,iconSrc:n,form:a,...i})=>r.a.createElement(r.a.Fragment,null,r.a.createElement(m,{type:"checkbox",iconSrc:n,...t,id:t.name,...i}),r.a.createElement(d,{iconSrc:n,htmlFor:t.name}));const p=Object(o.b)("label")` 
  background-image: url(${e=>e.userIcon});
  background-size: cover;
  height: 4em;
  width: 4em;
  border-radius: 50%;
  cursor: pointer;
  img {
    height: 4em;
    width: 4em;
    border-radius: 50%;
    cursor: pointer
  }
`,b=Object(o.b)("input")` 
  position: absolute; 
  left: -99999rem;
`;var g=({field:e,onChange:t,file:n,userIcon:a})=>r.a.createElement(p,{userIcon:a},r.a.createElement("img",{alt:"",src:n}),r.a.createElement(b,{type:"file",...e,id:e.name,onChange:t})),h=n(44),f=n(61),v=n(20);const w=Object(o.b)(s.c)`
  /* height: 10vw; */
  margin-top: 1em;
  border-radius: .5em;

  section {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
  }
`,x=Object(o.b)("div")` 
  display: flex;
  align-items: center;
  border-bottom: 1px solid gray;
  padding-bottom: 1vw;
  margin-bottom: 1vw;
  span {
    margin-left: 1vw;
  }
`,E=Object(o.b)("div")`
  h1 {
    width: 100%;
    margin: 0;
    text-align: center;
    padding-bottom: .5em;
    border-bottom: 1px solid black;
  }
 `;Object(o.b)("div")`
  display: flex;
  align-items: center;
`;var y=()=>{var e;const[t,n]=Object(a.useState)(null),[o,c]=Object(a.useState)(null),d=Object(a.useCallback)((e,t)=>{t("file",e.currentTarget.files[0]);const a=new FileReader,r=e.target.files[0];a.onloadend=()=>{n(a.result)},a.readAsDataURL(r)},[]),m=Object(a.useCallback)((e,t,n)=>{e.target.checked?(c(t),n(e.target.name,!0)):(c(null),n(e.target.name,!1))},[]),{uploadUserIcon:p,updateUserIcon:b}=Object(v.a)(f.b),y=null===(e=Object(l.c)(e=>e.session.currentUser))||void 0===e?void 0:e.id,k=Object(l.c)(e=>e.users.list).find(e=>e.id===y);return r.a.createElement(E,null,r.a.createElement(s.d,{initialValues:{file:""},validate:()=>({}),onSubmit:(e,{setSubmitting:t})=>{if(e.file instanceof File){const n=new FormData;n.append("image",e.file),p(n,null==k?void 0:k.username),t(!1)}else{var n;const t=null===(n=Object.entries(e).find(([,e])=>!0===e))||void 0===n?void 0:n[0];b({username:null==k?void 0:k.username,iconSrc:t})}}},({isSubmitting:e,setFieldValue:n})=>r.a.createElement(r.a.Fragment,null,r.a.createElement(w,null,r.a.createElement(i.a.Header,{closeButton:!0},r.a.createElement(i.a.Title,null,"Choose A Profile Image")),r.a.createElement(i.a.Body,{style:{textAlign:"center"}},r.a.createElement(x,null,r.a.createElement(s.b,{type:"file",name:"fileName",userIcon:null==k?void 0:k.iconSrc,file:t,component:g,onChange:e=>d(e,n)}),r.a.createElement("span",null,"Upload A Profile Picture")),"Or Choose An Avatar",r.a.createElement("section",null,new Array(16).fill(0).map((e,t)=>r.a.createElement(s.b,{onChange:e=>m(e,t,n),disabled:o!==t&&null!==o,key:String(t),iconSrc:`https://civil-dev.s3.us-west-1.amazonaws.com/profile_images/64_${t+1}.png`,name:"profile_img_"+(t+1),component:u})))),r.a.createElement(i.a.Footer,null,r.a.createElement(h.a,{type:"submit",disabled:e},"Submit"))))))};const k=r.a.lazy(()=>Promise.all([n.e(0),n.e(6)]).then(n.bind(null,306))),O=r.a.lazy(()=>Promise.all([n.e(0),n.e(1)]).then(n.bind(null,308))),j=r.a.lazy(()=>n.e(5).then(n.bind(null,309))),C="CREATE_TOPIC",S="CREATE_SUB_TOPIC",L="REPLY",z="ICON_FORM";t.e=({closeModal:e})=>{const{modalType:t,modalProps:n}=Object(l.c)(e=>e.ui),o=Object(l.c)(e=>e.ui.modalOpen);let s;switch(t){case C:s=r.a.createElement(k,null);break;case S:s=r.a.createElement(j,null);break;case L:s=r.a.createElement(O,{modalProps:n});break;case z:s=r.a.createElement(y,null)}return r.a.createElement(i.a,{contentClassName:"react-strap-modal",show:o,onHide:e,container:document.getElementById("main-container")},r.a.createElement(c,null,r.a.createElement(a.Suspense,{fallback:r.a.createElement("div",null,"Loading...")},s)))}},35:function(e,t,n){"use strict";n.d(t,"b",(function(){return a})),n.d(t,"a",(function(){return r})),n.d(t,"c",(function(){return i}));const a="OPEN_MODAL",r="CLOSE_MODAL",i="SHOW_SPINNER";t.d=(e={modalOpen:!1,loadingSpinner:{isOpen:!1}},t)=>{switch(t.type){case"SHOW_SPINNER":return{...e,loadingSpinner:{isOpen:t.payload}};case"OPEN_MODAL":return{...e,modalOpen:!0,...t.payload};case"CLOSE_MODAL":return{...e,modalOpen:!1};default:return e}}},42:function(e,t,n){"use strict";n.d(t,"a",(function(){return l})),n.d(t,"b",(function(){return o})),n.d(t,"d",(function(){return c})),n.d(t,"e",(function(){return s})),n.d(t,"f",(function(){return d})),n.d(t,"c",(function(){return m}));var a=n(6),r=n.n(a),i=n(7);const l=e=>r.a.post(i.a+"/topics",e),o=()=>r.a.get(i.a+"/topics"),c=(e,t)=>r.a.get(`${i.a}/topics/${e}/${t}`),s=e=>r.a.put(i.a+"/topics",e),d=(e,t,n)=>r.a.post(`${i.b}/topics/upload-media?fileType=${t}&fileFormat=${n}`,e),m=e=>r.a.get(`${i.b}/topics/link-meta-data?url=${e}`)},44:function(e,t,n){"use strict";var a=n(0),r=n.n(a),i=n(1);const l=Object(i.b)("button")`
  position: relative;
  cursor: pointer;
  outline: none;
  border: none;
  font-family: inherit;
  display: block;
  border-radius: 0.5rem;;
  margin: 0em 1em;
  &:hover {
     letter-spacing: ${e=>e.small?"normal":"0.125rem"};
    }
  height: ${e=>e.small?"2em":"2.5em"};
  font-size: ${e=>e.small?".7em":".9em"};
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.5s cubic-bezier(0.65,-0.25,0.25,1.95);
  font-weight: 900;
  color: white;
  padding: ${e=>e.small?".3em .8em":".5em 1em"};
  background: var(--m-primary-background-2-color);
  text-transform: uppercase;
  width: ${e=>e.width||"unset"};;
  :hover {
    filter: brightness(.8);
  }
`;t.a=({children:e,small:t,onClick:n,width:a,type:i})=>r.a.createElement(l,{onClick:n,small:t,width:a,type:i},e)},47:function(e,t,n){"use strict";n.d(t,"a",(function(){return l})),n.d(t,"b",(function(){return o})),n.d(t,"d",(function(){return c})),n.d(t,"c",(function(){return s}));const a=(e,t,n)=>{const{children:r}=n;if(t.parentId!==n.data.id)for(let i=0;i<r.length;i+=1)a(e,t,n.children[i]);else n.children=[...r,{data:t,children:[]}]},r=(e,t)=>{const{children:n}=t;if(e.commentId!==t.data.id)for(let t=0;t<n.length;t+=1)r(e,n[t]);else t.data={...t.data,...e}},i=(e,t)=>{const n=t.list.find(t=>{var n;return t.data.id===(null===(n=e.payload)||void 0===n?void 0:n.rootId)});if(e.payload.rootId)return r(e.payload,n),JSON.parse(JSON.stringify(t));const a=t.list.map(t=>t.data.id===e.payload.commentId?{...t,data:{...t.data,...e.payload}}:t);return{...t,list:a}},l="ADD_COMMENT",o="GET_ALL_COMMENTS",c="UPDATE_COMMENT_LIKES",s="UPDATE_COMMENT_CIVILITY",d=new Map([[l,(e,t)=>{const n=t.list.find(t=>{var n;return t.data.id===(null===(n=e.payload)||void 0===n?void 0:n.rootId)});return null===e.payload.parentId?{...t,list:[{data:e.payload,children:[]},...t.list]}:(a(n,e.payload,n),JSON.parse(JSON.stringify(t)))}],[o,(e,t)=>({...t,list:e.payload})],[c,i],[s,i]]);t.e=(e={list:[]},t)=>d.has(t.type)?d.get(t.type)(t,e):e},48:function(e,t,n){"use strict";n.d(t,"a",(function(){return i})),n.d(t,"b",(function(){return l})),n.d(t,"c",(function(){return o})),n.d(t,"d",(function(){return c}));var a=n(6),r=n.n(a);const i="ADD_SESSION_DATA_BACKEND",l="ADD_SESSION_DATA_CLERK",o="LOG_OUT",c="UPDATE";t.e=(e={},t)=>{switch(t.type){case i:return{...e,currentUser:{...e.currentUser,civility:t.payload.civility}};case l:return{...e,currentUser:{...e.currentUser,...t.payload}};case o:return localStorage.setItem("jwt",null),(n=null)?r.a.defaults.headers.common.Authorization=n:delete r.a.defaults.headers.common.Authorization,{...e,currentUser:null};case c:return{...e,currentUser:t.payload};default:return e}var n}},51:function(e,t,n){"use strict";var a=n(55),r=n(11),i=n(47),l=n(59);t.a={createComment:e=>t=>{l.b(e).then(e=>{return t((n=e.data,{type:i.a,payload:n}));var n}).then(()=>{a.c.success("Saved Comment",{delay:1e3})}).catch(e=>a.c.error("Problem Saving Comment \n "+e,{autoClose:2500})).finally(()=>t(Object(r.a)()))},getAllComments:(e,t)=>n=>l.c(e,t).then(e=>{return n((t=e.data,{type:i.b,payload:t}));var t}),updateCommentLikes:e=>t=>l.e(e).then(e=>t((e=>({type:i.d,payload:e}))(e.data))),updateCommentCivility:e=>t=>l.d(e).then(e=>t((e=>({type:i.c,payload:e}))(e.data)))}},57:function(e,t,n){"use strict";n.d(t,"a",(function(){return a})),n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return i}));const a="ADD_TOPIC",r="GET_ALL_TOPICS",i="UPDATE_TOPIC_LIKES";t.d=(e={list:[]},t)=>{switch(t.type){case a:return e.list.find(e=>e.id===t.payload.id)?e:{...e,list:[t.payload,...e.list]};case r:return{...e,list:t.payload};case i:const n=e.list.map(e=>e.id===t.payload.id?{...e,likes:t.payload.likes,liked:t.payload.liked}:e);return{...e,list:n};default:return e}}},59:function(e,t,n){"use strict";n.d(t,"b",(function(){return l})),n.d(t,"c",(function(){return o})),n.d(t,"e",(function(){return c})),n.d(t,"d",(function(){return s})),n.d(t,"a",(function(){return d}));var a=n(6),r=n.n(a),i=n(7);const l=e=>r.a.post(i.a+"/comments",e),o=(e,t)=>r.a.get(`${i.a}/comments?subtopicId=${e}&userId=${t}`),c=e=>r.a.put(i.a+"/comments",e),s=e=>r.a.put(i.a+"/comments/civility",e),d=e=>r.a.post(i.b+"/comments/toxicity",e)},61:function(e,t,n){"use strict";n.d(t,"a",(function(){return c}));var a=n(11),r=n(48),i=n(6),l=n.n(i),o=n(7);const c=e=>({type:r.b,payload:e}),s=e=>({type:r.a,payload:e}),d=e=>({type:r.d,payload:e});t.b={logout:()=>e=>{e({type:r.c})},getCurrentUser:e=>t=>(e=>l.a.get(`${o.a}/users?userId=${e}`))(e).then(e=>t(s(e.data))),signIn:e=>t=>(e=>l.a.post(o.a+"/login",e))(e).then(e=>t(s(JSON.parse(e.data).token))).then(()=>t(Object(a.a)())),updateUserIcon:e=>t=>{return(n=e,l.a.put(o.a+"/users",n)).then(e=>t(d(e.data)));var n},uploadUserIcon:(e,t)=>n=>((e,t)=>l.a.post(`${o.b}/users/uploadIcon?username=${t}`,e))(e,t).then(e=>n(d(e.data)))}},65:function(e,t,n){"use strict";n.d(t,"a",(function(){return a})),n.d(t,"b",(function(){return r}));const a="ADD_SUB_TOPIC",r="GET_ALL_SUB_TOPICS";t.c=(e={list:[]},t)=>{switch(t.type){case a:return e.list.find(e=>e.id===t.payload.id)?e:{...e,list:[...e.list,t.payload]};case r:return{...e,list:t.payload};default:return e}}},69:function(e,t,n){"use strict";var a=n(11),r=n(65),i=n(6),l=n.n(i),o=n(7);const c=e=>({type:r.a,payload:e});t.a={createSubTopic:e=>t=>{return(n=e,l.a.post(o.a+"/subtopics",n)).then(e=>t(c(e.data))).then(()=>t(Object(a.a)()));var n},getAllSubTopics:e=>t=>(e=>l.a.get(`${o.a}/subtopics?topicId=${e}`))(e).then(e=>{return t((n=e.data,{type:r.b,payload:n}));var n}).then(()=>t(Object(a.a)())),getSubTopic:e=>t=>(e=>l.a.get(`${o.a}/subtopics/${e}`))(e).then(e=>t(c(e.data)))}},7:function(e,t,n){"use strict";n.d(t,"a",(function(){return a})),n.d(t,"b",(function(){return r}));const a="http://localhost:8092/api/v1",r="http://localhost:5050/api/v1"}},[[116,4,7]],[0,1,6,2,5]]);